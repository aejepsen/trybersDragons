import Fighter from './Fighter';
import { SimpleFighter } from './SimpleFighter';

export default Fighter;
export { SimpleFighter };