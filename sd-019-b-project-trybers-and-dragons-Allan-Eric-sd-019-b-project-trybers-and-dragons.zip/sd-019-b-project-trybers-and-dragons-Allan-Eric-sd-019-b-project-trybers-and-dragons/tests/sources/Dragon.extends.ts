import Dragon from '../../src/Dragon';
import Monster from '../../src/Monster';

const d = new Dragon();
const f = (m: Monster) => { };
f(d);
