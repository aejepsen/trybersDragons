import { pvp } from '../../src';
import { PVP } from '../../src/Battle';

const func = (p: PVP) => { };
func(pvp);
