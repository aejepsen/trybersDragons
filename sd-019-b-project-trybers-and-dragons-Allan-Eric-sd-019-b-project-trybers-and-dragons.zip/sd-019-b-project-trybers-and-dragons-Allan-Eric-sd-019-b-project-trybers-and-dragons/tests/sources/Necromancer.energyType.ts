import * as Archetypes from '../../src/Archetypes';
const necromancer = new Archetypes.Necromancer('');
const result = () => necromancer.energyType;
