import Archetype, { Warrior } from '../../src/Archetypes';

const x = (y: Archetype) => {

};
x(new Warrior('Ramon'));