import Race, { Dwarf } from '../../src/Races';

const x = (y: Race) => {

};
x(new Dwarf('Dáin Iron Foot', 100));
