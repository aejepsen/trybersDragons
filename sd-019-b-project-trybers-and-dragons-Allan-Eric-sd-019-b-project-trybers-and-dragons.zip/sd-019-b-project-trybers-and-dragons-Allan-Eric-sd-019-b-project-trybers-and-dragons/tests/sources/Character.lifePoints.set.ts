import Character from '../../src/Character';

const c = new Character('');
c.lifePoints = 10;
