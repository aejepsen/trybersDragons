import Archetype from '../../src/Archetypes/Archetype';

const r = new Archetype('', 99);
