import Character from '../../src/Character';
new Character('').race;
