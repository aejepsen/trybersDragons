import Race, { Halfling } from '../../src/Races';

const x = (y: Race) => {

};
x(new Halfling('Lobélia Sacola-Bolseiro', 100));
