import * as Races from '../../src/Races';
const o = new Races.Orc('', 100);
