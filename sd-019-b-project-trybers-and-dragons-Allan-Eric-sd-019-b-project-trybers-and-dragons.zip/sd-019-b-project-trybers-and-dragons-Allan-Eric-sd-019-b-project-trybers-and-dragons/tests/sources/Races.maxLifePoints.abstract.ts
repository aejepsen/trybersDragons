import Race from '../../src/Races';

class RaceChild extends Race { }

