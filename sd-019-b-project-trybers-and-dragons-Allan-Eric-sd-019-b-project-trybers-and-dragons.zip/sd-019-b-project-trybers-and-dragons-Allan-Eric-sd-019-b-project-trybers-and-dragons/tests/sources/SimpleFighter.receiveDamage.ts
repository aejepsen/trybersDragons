import { SimpleFighter } from '../../src/Fighter';

const f = (obj: SimpleFighter) => {
  return obj.receiveDamage(10000);
}
