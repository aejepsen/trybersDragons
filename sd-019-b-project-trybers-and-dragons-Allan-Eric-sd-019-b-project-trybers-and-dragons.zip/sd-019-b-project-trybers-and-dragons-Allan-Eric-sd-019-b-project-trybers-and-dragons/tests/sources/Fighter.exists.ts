import Fighter from '../../src/Fighter';
