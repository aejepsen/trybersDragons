import Dragon from '../../src/Dragon';
const d = new Dragon();
