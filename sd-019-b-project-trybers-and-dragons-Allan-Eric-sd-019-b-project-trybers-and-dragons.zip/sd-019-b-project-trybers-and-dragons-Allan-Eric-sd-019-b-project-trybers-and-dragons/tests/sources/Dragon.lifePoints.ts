import Dragon from '../../src/Dragon';

const result = () => new Dragon().lifePoints;
