import { Dwarf } from '../../src/Races';
const dwarf = new Dwarf('Dáin Iron Foot', 100);
dwarf.name;
