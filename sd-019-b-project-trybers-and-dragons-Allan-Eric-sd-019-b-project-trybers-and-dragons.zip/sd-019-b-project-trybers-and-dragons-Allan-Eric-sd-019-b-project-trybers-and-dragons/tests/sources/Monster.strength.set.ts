import Monster from '../../src/Monster';
const m = new Monster();
m.strength = 10;
