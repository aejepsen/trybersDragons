import { Orc } from '../../src/Races';
const o = new Orc('Shagrat', 100);
const result = () => o.maxLifePoints;
