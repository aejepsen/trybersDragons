import * as Archetypes from '../../src/Archetypes';
const mage = new Archetypes.Mage('Alex');
const result = () => mage.name;
