import Race from '../../src/Races';

Race.createdRacesInstances;
