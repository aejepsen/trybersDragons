import * as Archetypes from '../../src/Archetypes';
const mage = new Archetypes.Mage('');
const result = () => mage.energyType;
