import Archetype, { Necromancer } from '../../src/Archetypes';

const x = (y: Archetype) => {

};
x(new Necromancer('Harry'));