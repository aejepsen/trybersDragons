import { Elf } from '../../src/Races';
const e = new Elf('Lúthien', 100);
e.dexterity;
