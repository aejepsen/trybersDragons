import Energy from '../../src/Energy';

let x: Energy = {
  type_: 'mana'
};
