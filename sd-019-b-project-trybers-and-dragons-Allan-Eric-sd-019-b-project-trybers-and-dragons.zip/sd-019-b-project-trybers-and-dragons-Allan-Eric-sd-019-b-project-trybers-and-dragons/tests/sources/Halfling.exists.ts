import * as Races from '../../src/Races';
const h = new Races.Halfling('', 100);
