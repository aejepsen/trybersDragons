import { SimpleFighter } from '../../src/Fighter';
