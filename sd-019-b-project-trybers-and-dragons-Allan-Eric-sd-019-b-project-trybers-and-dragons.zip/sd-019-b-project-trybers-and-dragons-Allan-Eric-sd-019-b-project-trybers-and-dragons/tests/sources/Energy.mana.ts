import { EnergyType } from '../../src/Energy';

let x: EnergyType = 'mana';
