import Energy from '../../src/Energy';

let x: Energy = {
  amount: 45,
  type_: 'mana'
};
