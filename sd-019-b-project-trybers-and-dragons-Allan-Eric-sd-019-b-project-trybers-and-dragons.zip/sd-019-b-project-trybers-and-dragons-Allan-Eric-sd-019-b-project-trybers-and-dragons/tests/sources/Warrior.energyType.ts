import * as Archetypes from '../../src/Archetypes';
const warrior = new Archetypes.Warrior('');
const result = () => warrior.energyType;
