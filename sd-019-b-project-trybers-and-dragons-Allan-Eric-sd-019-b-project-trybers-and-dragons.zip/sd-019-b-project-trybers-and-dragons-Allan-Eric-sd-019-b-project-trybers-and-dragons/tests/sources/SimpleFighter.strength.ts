import { SimpleFighter } from '../../src/Fighter';

const f = (obj: SimpleFighter): number => {
  return obj.strength;
}
