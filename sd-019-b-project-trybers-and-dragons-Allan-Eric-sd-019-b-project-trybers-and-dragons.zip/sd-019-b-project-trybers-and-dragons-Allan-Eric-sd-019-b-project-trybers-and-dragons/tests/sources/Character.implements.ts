import Fighter from '../../src/Fighter';
import Character from '../../src/Character';

const x = (y: Fighter) => { };
x(new Character(''));
