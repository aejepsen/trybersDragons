import Character from '../../src/Character';

const c = new Character('');
c.dexterity;
